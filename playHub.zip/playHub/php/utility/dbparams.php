<?php
define("connection", "mysql:host=localhost;dbname=coppola_603355");
define("user", "root");
define("pass", "");